var searchData=
[
  ['insert',['insert',['../classbadgerdb_1_1_buf_hash_tbl.html#a92480d460ddb07e8b04ab7f99107e334',1,'badgerdb::BufHashTbl']]],
  ['insertrecord',['insertRecord',['../classbadgerdb_1_1_page.html#ad0b1e85fe7849fb767dd8c21a8053cf4',1,'badgerdb::Page']]],
  ['insufficientspaceexception',['InsufficientSpaceException',['../classbadgerdb_1_1_insufficient_space_exception.html#a05ee1817c52c8bc284712fd5aef305a0',1,'badgerdb::InsufficientSpaceException']]],
  ['invalidpageexception',['InvalidPageException',['../classbadgerdb_1_1_invalid_page_exception.html#a95454bbb13eafd87874c0dd538cc4fa8',1,'badgerdb::InvalidPageException']]],
  ['invalidrecordexception',['InvalidRecordException',['../classbadgerdb_1_1_invalid_record_exception.html#a317a2fda3088cbf04a24189f089a68ed',1,'badgerdb::InvalidRecordException']]],
  ['invalidslotexception',['InvalidSlotException',['../classbadgerdb_1_1_invalid_slot_exception.html#a60f721f46b7aeacc655e1f3f0423314d',1,'badgerdb::InvalidSlotException']]],
  ['isopen',['isOpen',['../classbadgerdb_1_1_file.html#a64836156a9bb5f81d2c2c4e6f3ada24d',1,'badgerdb::File']]]
];
