var searchData=
[
  ['accesses',['accesses',['../structbadgerdb_1_1_buf_stats.html#a3e7eb386ac728ed028bd2a8bb7960827',1,'badgerdb::BufStats']]],
  ['allocatepage',['allocatePage',['../classbadgerdb_1_1_file.html#a7d0e047bcc8dc4cee36aac5b2060bbe3',1,'badgerdb::File']]],
  ['allocpage',['allocPage',['../classbadgerdb_1_1_buf_mgr.html#ab9ae3b12aac55b119b5763e3de2a4d2b',1,'badgerdb::BufMgr']]]
];
