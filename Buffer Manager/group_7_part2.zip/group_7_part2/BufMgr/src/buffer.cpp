/**
 * @author See Contributors.txt for code contributors and overview of BadgerDB.
 *
 * @section LICENSE
 * Copyright (c) 2012 Database Group, Computer Sciences Department, University of Wisconsin-Madison.
 */

/**
 * Name: Qian Zhang
 * Student id: 9078035962
 * Porpuse of the file: Define the functions of BufMgr class
*/
#include <memory>
#include <iostream>
#include "buffer.h"
#include "file_iterator.h"
#include "exceptions/buffer_exceeded_exception.h"
#include "exceptions/page_not_pinned_exception.h"
#include "exceptions/page_pinned_exception.h"
#include "exceptions/bad_buffer_exception.h"
#include "exceptions/hash_not_found_exception.h"
#include "exceptions/hash_table_exception.h"
#include "exceptions/hash_already_present_exception.h"

namespace badgerdb { 
/**
 * Function:
 * Class constructor.
 * Allocates an array for the buffer pool with bufs page frames and
 * a corresponding BufDesc table. Hash talbe will start out in an empty state.
 * @param bufs length of buffer
*/
BufMgr::BufMgr(std::uint32_t bufs)
	: numBufs(bufs) {
	bufDescTable = new BufDesc[bufs];

  for (FrameId i = 0; i < bufs; i++) 
  {
  	bufDescTable[i].frameNo = i;
  	bufDescTable[i].valid = false;
  }

  bufPool = new Page[bufs];

	int htsize = ((((int) (bufs * 1.2))*2)/2)+1;
  hashTable = new BufHashTbl (htsize);  // allocate the buffer hash table

  clockHand = bufs - 1;
}

/**
 * Function:
 * Class destructor.
 * Flushes out all dirty pages and deallocates the buffer pool and BufDesc table
*/
BufMgr::~BufMgr() {
	for (FrameId i = 0; i < numBufs; i++) {
		BufDesc bufDescTmp = bufDescTable[i];
		//If the page is dirty
		if (bufDescTmp.dirty == true) {
			File* file = bufDescTmp.file;
			Page page = bufPool[i];
			//flush it to file
			file->writePage(page);
		}
	}
	//deallocate
	delete[]bufPool;
	delete[]bufDescTable;
}

/**
 * Function:
 * Advance clock to next frame in the buffer pool
*/
void BufMgr::advanceClock()
{
	if (clockHand == numBufs - 1)
		clockHand = 0;
	else
		clockHand++;
}

/**
 * Function:
 * Allocates a free frame using clock algorithm.
 * If the page in the frame is dirtied, write it back to disk
 * If the there is a valid page in the frame, remove the entry from hash table
 * @param frame Reference to frame number. Used to fetch the frame number allocated.
 * @throws BufferExceededException If all pages are pinned
*/
void BufMgr::allocBuf(FrameId & frame) 
{
	advanceClock();
	bool flag = true;
	FrameId pinNum = 0;
	while (flag)
	{
		BufDesc& bufDecTmp = bufDescTable[clockHand];
		if (clockHand == 0)
			pinNum = 0;
		if (bufDecTmp.pinCnt != 0)
			pinNum++;
		//if all pages are pinned, throw exception
		if (pinNum == numBufs) {
			throw BufferExceededException();
		}
		//if the page is invalid, use it directly
		if (bufDecTmp.valid == false) {
			frame = clockHand;
			flag = false;
		}
		//if it's valid, if the referenced bit is true, set it to false
		else if (bufDecTmp.refbit == true) {
			bufDecTmp.refbit = false;
			advanceClock();
		}
		//if it's false, see if it's pinned
		else if (bufDecTmp.pinCnt == 0) {
			//unpinned, if it's dirty, flush it to file, then use this frame
			if (bufDecTmp.dirty == true) {
				File* file = bufDecTmp.file;
				Page page = bufPool[clockHand];
				PageId pageNo = bufDecTmp.pageNo;
				FrameId fid;
				file->writePage(page);
				try {
					//if the page is in hashtable
					hashTable->lookup(file, pageNo, fid);
					//remove the entry
					hashTable->remove(file, pageNo);
					//remove this page from buffer
					bufPool[fid] = Page();
					//reset the state for the frame
					bufDescTable[fid].Clear();
				}
				catch (HashNotFoundException e) {
					std::cout << "HashNotFoundException" << "\n";
				}
			}
			frame = clockHand;
			flag = false;
		}
		else {
			//if it's pinned, see next frame
			advanceClock();
		}
	}
}

/**
 * Function:
 * Read the given page from the file into a frame and returns the pointer to page.
 * If the requested page is already in buffer pool, pointer to that frame is returned
 * otherwise a new frame is allocated from buffer pool for reading the page
 * and an entry of hash table is inserted.
 * @param file File object
 * @param pageNo Page number in the file to be read
 * @param page Reference to page pointer. Used to fetch the Page object in which page from
 * file is read in.
*/
void BufMgr::readPage(File* file, const PageId pageNo, Page*& page)
{
	FrameId frameNo;
	try{
		//if the page is in buff, pincnt+1, return the pointer
		hashTable->lookup(file, pageNo, frameNo);
		bufDescTable[frameNo].pinCnt++;
		page = &(bufPool[frameNo]);
	}
	catch (HashNotFoundException e){
		//not in the buff, allocate a frame for the page
		allocBuf(frameNo);
		//write the page to the frame
		Page tmpPage = file->readPage(pageNo);
		bufPool[frameNo] = tmpPage;
		//initial state for the frame
		bufDescTable[frameNo].Set(file, pageNo);
		page = &(bufPool[frameNo]);
		//insert an entry to hashtable
		try {
			hashTable->insert(file, pageNo, frameNo);
		}
		catch (HashTableException e) {
			std::cout << "HashTableException" << "\n";
		}
	}
}

/**
 * Function:
 * Decrements the pinCnt of the frame containing(file, pageNo).
 * If dirty is true, set dirty bit.
 * Do nothing if page is not found in the hash table lookup.
 * @param file File object
 * @param pageNo Page number in the file to be read
 * @param dirty True if the page to be unpinned needs to be marked dirty
 * @throws PageNotPinnedException If the page is already unpinned
*/
void BufMgr::unPinPage(File* file, const PageId pageNo, const bool dirty) 
{
	FrameId frameNo;
	try {
		hashTable->lookup(file, pageNo, frameNo);
		//if the page in the buffer and dirtied
		if (dirty == true) {
			bufDescTable[frameNo].dirty = true;
		}
		//decrement pin count
		if (bufDescTable[frameNo].pinCnt != 0)
			bufDescTable[frameNo].pinCnt--;
		//if pin count is already 0, throw exception
		else
			throw PageNotPinnedException(file->filename(), pageNo, frameNo);
	}
	catch (HashNotFoundException e){
		std::cout << "HashNotFoundException" << "\n";
	}
}

/**
 * Function:
 * Scan bufTable for pages belonging to the file.
 * If the page is dirty, write it the disk.
 * Remove pages from hash table.
 * Clear the frame and its description.
 * @param file File object
 * @throws PagePinnedException If the page is already unpinned
 * @throws BadBufferException If an invalid page belonging to the file is encountered
*/
void BufMgr::flushFile(const File* file) 
{
	File* file1 = const_cast<File*>(file);
	FrameId frameNo;
	//for all the pages in a file
	for (FileIterator iter = file1->begin(); iter != file1->end(); ++iter)
	{
		try {
			Page iterPage = iter.operator*();
			//if a page is in hashtable
			hashTable->lookup(file1, iterPage.page_number(), frameNo);
			//if page pinned, throw exception
			if (bufDescTable[frameNo].pinCnt != 0) {
				throw PagePinnedException(file1->filename(), iterPage.page_number(), frameNo);
			}
			//if page is invalid, throw exception need to be catched in main
			if (bufDescTable[frameNo].valid == false) {
				throw BadBufferException(frameNo, bufDescTable[frameNo].dirty, bufDescTable[frameNo].valid, bufDescTable[frameNo].refbit);
			}
			//and it's dirty
			if (bufDescTable[frameNo].dirty == true) {
				Page tmpPage = bufPool[frameNo];
				//flush it from buffer to file
				file1->writePage(tmpPage);
			}
			//remove the entry for hashtable
			hashTable->remove(file1, iterPage.page_number());
			//remove the page from buffer and reset its state
			bufPool[frameNo] = Page();
			bufDescTable[frameNo].Clear();
		}
		catch (HashNotFoundException e) {
		}
	}
}

/**
 * Function:
 * Allocates a new, empty page in the file.
 * The newly allocated page in assigned a frame in the buffer pool.
 * An entry is inserted into the hash table
 * @param file File object
 * @param pageNo Page number. The number assigned to the page in the file is returned via this reference
 * @param page Reference to Page pointer. The pointer to buffer frame allocated is returned via this reference
*/
void BufMgr::allocPage(File* file, PageId &pageNo, Page*& page) 
{
	FrameId frameNo;
	//allocate an empty page in the file
	Page newPage = file->allocatePage();
	//allocate a frame for the new page
	allocBuf(frameNo);
	pageNo = newPage.page_number();
	//write the page to the frame
	bufPool[frameNo] = newPage;
	try {
		//insert an entry into hashtable
		hashTable->insert(file, pageNo, frameNo);
		//initial the state for the frame
		bufDescTable[frameNo].Set(file, pageNo);
		//return the pointer of the frame
		page = &(bufPool[frameNo]);
	}
	catch (HashAlreadyPresentException e) {
		std::cout << "HashAlreadyPresentException" << "\n";
	}
	catch (HashTableException e) {
		std::cout << "HashTableException" << "\n";
	}
}

/**
 * Function:
 * Delete a page from a file.
 * If the page is in buffer pool, delete the entry from hash table, free the frame
 * and clear the description of the frame firstly.
 * @param file File object
 * @param pageNo Page number
*/
void BufMgr::disposePage(File* file, const PageId PageNo)
{
	FrameId frameNo;
	try {
		//if the page is in hashtable
		hashTable->lookup(file, PageNo, frameNo);
		//
		if (bufDescTable[frameNo].pinCnt != 0) {
			throw PagePinnedException(file->filename(), PageNo, frameNo);
		}
		//remove the entry
		hashTable->remove(file, PageNo);
		//remove this page from buffer
		bufPool[frameNo] = Page();
		//reset the state for the frame
		bufDescTable[frameNo].Clear();
		//delete this page from file
		file->deletePage(PageNo);
	}
	catch (HashNotFoundException e) {
		//if not in hashtable, delete it directly
		file->deletePage(PageNo);
	}
}

/**
* Function:
* Print member variable values
*/
void BufMgr::printSelf(void) 
{
  BufDesc* tmpbuf;
	int validFrames = 0;
  
  for (std::uint32_t i = 0; i < numBufs; i++)
	{
  	tmpbuf = &(bufDescTable[i]);
		std::cout << "FrameNo:" << i << " ";
		tmpbuf->Print();

  	if (tmpbuf->valid == true)
    	validFrames++;
  }

	std::cout << "Total Number of Valid Frames:" << validFrames << "\n";
}

}
