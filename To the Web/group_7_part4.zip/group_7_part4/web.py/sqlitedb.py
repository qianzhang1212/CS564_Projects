import web

db = web.database(dbn='sqlite',
        db='AuctionBase.db' #TODO: add your SQLite database filename
    )

######################BEGIN HELPER METHODS######################

# Enforce foreign key constraints
# WARNING: DO NOT REMOVE THIS!
def enforceForeignKey():
    db.query('PRAGMA foreign_keys = ON')

# initiates a transaction on the database
def transaction():
    return db.transaction()
# Sample usage (in auctionbase.py):
#
# t = sqlitedb.transaction()
# try:
#     sqlitedb.query('[FIRST QUERY STATEMENT]')
#     sqlitedb.query('[SECOND QUERY STATEMENT]')
# except Exception as e:
#     t.rollback()
#     print str(e)
# else:
#     t.commit()
#
# check out http://webpy.org/cookbook/transactions for examples

# returns the current time from your database
def getTime():
    # TODO: update the query string to match
    # the correct column and table name in your database
    query_string = 'select Time from CurrentTime'
    results = query(query_string)
    # alternatively: return results[0]['currenttime']
    return results[0].Time # TODO: update this as well to match the
                                  # column name

# returns a single item specified by the Item's ID in the database
# Note: if the `result' list is empty (i.e. there are no items for a
# a given ID), this will throw an Exception!
def getItemById(item_id):
    # TODO: rewrite this method to catch the Exception in case `result' is empty
    query_string = 'select * from Items where ItemID = $itemID'
    result = query(query_string, {'itemID': item_id})
    return result

# wrapper method around web.py's db.query method
# check out http://webpy.org/cookbook/query for more info
def query(query_string, vars = {}):
    return list(db.query(query_string, vars))

#####################END HELPER METHODS#####################

#TODO: additional methods to interact with your database,
# e.g. to update the current time
def updateCurrTime(selectedTime):
    currTime = getTime()
    db.update('CurrentTime',where='Time = $currTime',vars={'currTime':currTime},Time = selectedTime)
    #db.delete('CurrentTime',where='Time = $currTime')
    #db.insert('CurrentTime',Time = selectedTime)

def enterBid(itemID,userID,price):
    currTime = getTime()
    db.insert('Bids',ItemID = int(itemID),UserID = userID, Amount = float(price), Time = currTime)

def getItemByCategory(category):
    # TODO: rewrite this method to catch the Exception in case `result' is empty
    query_string = 'select * from Items,Categories where Items.ItemID = Categories.ItemID and Categories.Category = $category'
    result = query(query_string, {'category': category})
    return result

def getCategoryById(itemID):
    query_string = 'select Category from Categories where ItemID = $itemID'
    result = query(query_string, {'itemID': itemID})
    return result

def getBidsById(itemID):
    query_string = 'select * from Bids where ItemID = $itemID'
    result = query(query_string, {'itemID': itemID})
    return result

def checkUserbyUid(userID):
    query_string = 'select * from Users where UserID = $userID'
    result = query(query_string, {'userID': userID})
    return result

def setItemCurrently(itemID,currently):
    db.update('Items',where='ItemID = $itemID',vars={'itemID':itemID},Currently = currently)

def getItem(itemID,category,description,minP,maxP,status,userID):
    if(itemID=='' and category=='' and description=='' and minP =='' and maxP =='' and userID=='' and status=='all'):
        query_string = 'select * from Items'
        result = query(query_string)
    else:
        where = ''
        currTime = getTime()
        if(description!=''):
            where = where+'Description like $description'+' and '
        if(minP!=''):
            where = where+'First_Bid = $minP'+' and '
        if(maxP!=''):
            where = where+'Buy_Price = $maxP'+' and '
        if(status!=''):
            if(status=='open'):
                where = where+'Started<=$currTime and Ends>=$currTime'+' and '
                where = where+'(Currently<Buy_Price or Buy_Price is $None)'+' and '
            if(status=='close'):
                where = where+'(Ends<$currTime or (Currently>=Buy_Price and Buy_Price is not $None))'+' and '
            if(status=='notStarted'):
                where = where+'Started>=$currTime'+' and '
        if(userID!=''):
            where = where+'Seller_UserID=$userID'+' and '
        if(category!=''):
            where = where+'Items.ItemID = Categories.ItemID'+' and '
            where = where+'Categories.Category = $category'+' and '
            if(itemID!=''):
                where = where+'Items.ItemID = $itemID'+' and '
            where = where[:-5]
            query_string = 'select * from Items,Categories where '+where
            description_tmp = '%'+description+'%'
            result = query(query_string, {'itemID':itemID,'description':description_tmp,'minP':minP,'maxP':maxP,'currTime':currTime,'category':category,'None':'NULL','userID':userID})
        else:
            if(itemID!=''):
                where = where+'ItemID = $itemID'+' and '
            where = where[:-5]
            query_string = 'select * from Items where '+where
            description_tmp = '%'+description+'%'
            result = query(query_string, {'itemID':itemID,'description':description_tmp,'minP':minP,'maxP':maxP,'currTime':currTime,'None':'NULL','userID':userID})
    return result