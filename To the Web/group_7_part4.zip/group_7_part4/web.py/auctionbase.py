#!/usr/bin/env python

import sys; sys.path.insert(0, 'lib') # this line is necessary for the rest
import os                             # of the imports to work!

import web
import sqlitedb
from jinja2 import Environment, FileSystemLoader
from datetime import datetime

###########################################################################################
##########################DO NOT CHANGE ANYTHING ABOVE THIS LINE!##########################
###########################################################################################

######################BEGIN HELPER METHODS######################

# helper method to convert times from database (which will return a string)
# into datetime objects. This will allow you to compare times correctly (using
# ==, !=, <, >, etc.) instead of lexicographically as strings.

# Sample use:
# current_time = string_to_time(sqlitedb.getTime())

def string_to_time(date_str):
    return datetime.strptime(date_str, '%Y-%m-%d %H:%M:%S')

# helper method to render a template in the templates/ directory
#
# `template_name': name of template file to render
#
# `**context': a dictionary of variable names mapped to values
# that is passed to Jinja2's templating engine
#
# See curr_time's `GET' method for sample usage
#
# WARNING: DO NOT CHANGE THIS METHOD
def render_template(template_name, **context):
    extensions = context.pop('extensions', [])
    globals = context.pop('globals', {})

    jinja_env = Environment(autoescape=True,
            loader=FileSystemLoader(os.path.join(os.path.dirname(__file__), 'templates')),
            extensions=extensions,
            )
    jinja_env.globals.update(globals)

    web.header('Content-Type','text/html; charset=utf-8', unique=True)

    return jinja_env.get_template(template_name).render(context)

#####################END HELPER METHODS#####################

urls = ('/currtime', 'curr_time',
        '/selecttime', 'select_time',
        # TODO: add additional URLs here
        # first parameter => URL, second parameter => class name
        '/search', 'search',
        '/add_bid', 'add_bid',
        '/search_aution_infor/(.*)','auction_infor'
        )

class curr_time:
    # A simple GET request, to '/currtime'
    #
    # Notice that we pass in `current_time' to our `render_template' call
    # in order to have its value displayed on the web page
    def GET(self):
        current_time = sqlitedb.getTime()
        return render_template('curr_time.html', time = current_time)

class auction_infor:
    def GET(self,name):
        Name = web.input(name=None)

        t = sqlitedb.transaction()
        try:
            result = sqlitedb.getItemById(Name.name)
            if(len(result)==0):
                update_message = 'Item does not exist'
            else:
                category = sqlitedb.getCategoryById(Name.name)
                all_category = "";
                for caty in category:
                    for key in caty:
                        all_category = all_category+caty[key]+','
                all_category = all_category[:-1]
                result.append({"Category":all_category})

                bids = sqlitedb.getBidsById(Name.name)
                if(len(bids)==0):
                    result.append({"Bids":"No bids"})
                    current_time = sqlitedb.getTime()
                    startTime = result[0]["Started"]
                    endTime = result[0]["Ends"]
                    if(current_time<endTime and current_time>=startTime):
                        result.append({"Status":"Open"})
                    if(current_time<startTime):
                        result.append({"Status":"Not Started"})
                    if(current_time>=endTime):
                        result.append({"Status":"Closed"})
                    sqlitedb.setItemCurrently(Name.name,0)
                    result[0]["Currently"] = 0
                else:
                    i = 1
                    maxPrice = 0
                    maxName = ""
                    for bid in bids:
                        bid_infor = "Name:"+bid["UserID"]+"; "
                        bid_infor = bid_infor+"Time:"+bid["Time"]+"; "
                        bid_infor = bid_infor+"Price:"+str(bid["Amount"])
                        if(bid["Amount"]>maxPrice):
                            maxName = bid["UserID"]
                            maxPrice = bid["Amount"]
                        tmp = "Bid"+str(i)
                        result.append({tmp:bid_infor})
                        i = i+1;

                    sqlitedb.setItemCurrently(Name.name,maxPrice)
                    result[0]["Currently"] = maxPrice

                    close_flag = 0
                    if(result[0]["Buy_Price"]!=None and maxPrice>=result[0]["Buy_Price"]):
                        close_flag = 1

                    current_time = sqlitedb.getTime()
                    startTime = result[0]["Started"]
                    endTime = result[0]["Ends"]
                    if(current_time<endTime and current_time>=startTime and close_flag==0):
                        result.append({"Status":"Open"})
                        status = 0
                    if(current_time<startTime):
                        result.append({"Status":"Not Started"})
                        status = 1
                    if(current_time>=endTime or close_flag==1):
                        result.append({"Status":"Closed"})
                        status = 2

                    if(status==2):
                        maxInfor = "Name:"+maxName+"; "+"Price:"+str(maxPrice)
                        result.append({"Winner":maxInfor})

                update_message = 'Detail Information'
        except Exception as e:
            t.rollback()
            update_message = str(e)
            print str(e)
        else:
            t.commit()

        return render_template('auction_infor.html',message = update_message,search_result = result)
    """
    def POST(self):

        post_params = web.input()
        itemID = post_params['itemID']
        t = sqlitedb.transaction()
        try:
            result = sqlitedb.getItemById(itemID)
            if(len(result)==0):
                update_message = 'Item does not exist'
            else:
                category = sqlitedb.getCategoryById(itemID)
                all_category = "";
                for caty in category:
                    for key in caty:
                        all_category = all_category+caty[key]+','
                all_category = all_category[:-1]
                result.append({"Category":all_category})

                bids = sqlitedb.getBidsById(itemID)
                i = 1
                maxPrice = 0
                maxName = ""
                for bid in bids:
                    bid_infor = "Name:"+bid["UserID"]+"; "
                    bid_infor = bid_infor+"Time:"+bid["Time"]+"; "
                    bid_infor = bid_infor+"Price:"+str(bid["Amount"])
                    if(bid["Amount"]>maxPrice):
                        maxName = bid["UserID"]
                        maxPrice = bid["Amount"]
                    tmp = "Bid"+str(i)
                    result.append({tmp:bid_infor})
                    i = i+1;

                sqlitedb.setItemCurrently(itemID,maxPrice)
                result[0]["Currently"] = maxPrice

                close_flag = 0
                if(result[0]["Buy_Price"]!=None and maxPrice>=result[0]["Buy_Price"]):
                    close_flag = 1

                current_time = sqlitedb.getTime()
                startTime = result[0]["Started"]
                endTime = result[0]["Ends"]
                if(current_time<endTime and current_time>=startTime and close_flag==0):
                    result.append({"Status":"Open"})
                    status = 0
                if(current_time<startTime):
                    result.append({"Status":"Not Started"})
                    status = 1
                if(current_time>=endTime or close_flag==1):
                    result.append({"Status":"Closed"})
                    status = 2

                if(status==2):
                    maxInfor = "Name:"+maxName+"; "+"Price:"+str(maxPrice)
                    result.append({"Winner":maxInfor})

                update_message = 'Successful'
        except Exception as e:
            t.rollback()
            update_message = str(e)
            print str(e)
        else:
            t.commit()

        return render_template('auction_infor.html', message = update_message,search_result = result)
        """


class select_time:
    # Aanother GET request, this time to the URL '/selecttime'
    def GET(self):
        return render_template('select_time.html')

    # A POST request
    #
    # You can fetch the parameters passed to the URL
    # by calling `web.input()' for **both** POST requests
    # and GET requests
    def POST(self):
        post_params = web.input()
        MM = post_params['MM']
        dd = post_params['dd']
        yyyy = post_params['yyyy']
        HH = post_params['HH']
        mm = post_params['mm']
        ss = post_params['ss'];
        enter_name = post_params['entername']


        selected_time = '%s-%s-%s %s:%s:%s' % (yyyy, MM, dd, HH, mm, ss)
        update_message = '(Hello, %s. Previously selected time was: %s.)' % (enter_name, selected_time)
        # TODO: save the selected time as the current time in the database
        #current_time = sqlitedb.getTime()
        t = sqlitedb.transaction()
        try:
            current_time = sqlitedb.getTime()
            if(len(selected_time)!=19):
                update_message = 'Time selected is invalid'
            else:
                if(selected_time>=current_time):
                    sqlitedb.updateCurrTime(selected_time)
                    update_message = 'Successful'
                else:
                    update_message = 'Time selected can not be earlier than time now'
        except Exception as e:
            t.rollback()
            update_message = str(e)
            print str(e)
        else:
            t.commit()
        # Here, we assign `update_message' to `message', which means
        # we'll refer to it in our template as `message'
        return render_template('select_time.html', message = update_message)

class search:
    def GET(self):
        return render_template('search.html')

    def POST(self):
        post_params = web.input()
        itemID = post_params['itemID']
        category = post_params['category']
        description = post_params['description']
        minP = post_params['minPrice']
        maxP = post_params['maxPrice']
        status = post_params['status']
        userID = post_params['userID']

        t = sqlitedb.transaction()
        try:
            result = sqlitedb.getItem(itemID,category,description,minP,maxP,status,userID)
            update_message = 'Successful'
        except Exception as e:
            t.rollback()
            update_message = str(e)
            print str(e)
        else:
            t.commit()
        return render_template('search.html', message = update_message,search_result = result)
        """
        #serach by item id
        t = sqlitedb.transaction()
        try:
            result = sqlitedb.getItemById(itemID)
            if(len(result)==0):
                update_message = 'No item with this ID'
            else:
                startTime = result[0]["Started"]
                endTime = result[0]["Ends"]

                bids = sqlitedb.getBidsById(itemID)
                maxPrice = 0
                for bid in bids:
                    if(bid["Amount"]>maxPrice):
                        maxPrice = bid["Amount"]
                sqlitedb.setItemCurrently(itemID,maxPrice)

                close_flag=0
                if(result[0]["Buy_Price"]!=None and maxPrice>=result[0]["Buy_Price"]):
                    close_flag = 1;

                current_time = sqlitedb.getTime()
                if(current_time<endTime and current_time>=startTime and close_flag==0):
                    result.append({"Status":"Open"})
                if(current_time<startTime):
                    result.append({"Status":"Not Started"})
                if(current_time>=endTime or close_flag == 1):
                    result.append({"Status":"Closed"})
                update_message = '(Successful)'
        except Exception as e:
            t.rollback()
            update_message = str(e)
            print str(e)
        else:
            t.commit()
        """

        #serach by category
        """
        t = sqlitedb.transaction()
        try:
            result = sqlitedb.getItemByCategory(category)
            if(len(result)==0):
                update_message = 'No item with this category'
            else:
                startTime = result[0]["Started"]
                endTime = result[0]["Ends"]
                current_time = sqlitedb.getTime()
                if(current_time<endTime and current_time>=startTime):
                    result.append({"Status":"Open"})
                if(current_time<startTime):
                    result.append({"Status":"Not Started"})
                if(current_time>=endTime):
                    result.append({"Status":"Closed"})
                update_message = '(Successful)'
        except Exception as e:
            t.rollback()
            update_message = str(e)
            print str(e)
        else:
            t.commit()
        """


        #return render_template('search.html', message = update_message,search_result = result)
        #return render_template('search.html', )

class add_bid:
    def GET(self):
        return render_template('add_bid.html')

    def POST(self):
        post_params = web.input()
        itemID = post_params['itemID']
        userID = post_params['userID']
        price = post_params['price']

        t = sqlitedb.transaction()
        try:
            result = sqlitedb.getItemById(itemID)
            if(len(result)==0):
                update_message = 'Item does not exist'
            else:
                startTime = result[0]["Started"]
                endTime = result[0]["Ends"]
                current_time = sqlitedb.getTime()
                seller = result[0]["Seller_UserID"]
                if(userID==str(seller)):
                    update_message = 'Seller can not add bid for your item'
                else:
                    bids = sqlitedb.getBidsById(itemID)
                    maxPrice = 0
                    for bid in bids:
                        if(bid["Amount"]>maxPrice):
                            maxPrice = bid["Amount"]
                    sqlitedb.setItemCurrently(itemID,maxPrice)

                    close_flag = 0
                    if(result[0]["Buy_Price"]!=None and maxPrice>=result[0]["Buy_Price"]):
                        close_flag = 1


                    if(current_time<endTime and current_time>=startTime and close_flag==0):

                        if(float(price)<=maxPrice):
                            update_message = 'Price lower than the current highest bid'
                        else:
                            userFound = sqlitedb.checkUserbyUid(userID)
                            if(len(userFound)==0):
                                update_message = 'User does not exist'
                            else:
                                sqlitedb.enterBid(itemID,userID,price)
                                update_message = 'Successful'
                    else:
                        update_message = 'Auction not open'
        except Exception as e:
            t.rollback()
            update_message = str(e)
            print str(e)
        else:
            t.commit()

        return render_template('add_bid.html', message = update_message)
###########################################################################################
##########################DO NOT CHANGE ANYTHING BELOW THIS LINE!##########################
###########################################################################################

if __name__ == '__main__':
    web.internalerror = web.debugerror
    app = web.application(urls, globals())
    app.add_processor(web.loadhook(sqlitedb.enforceForeignKey))
    app.run()
