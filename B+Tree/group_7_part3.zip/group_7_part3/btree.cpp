/**
 * @author See Contributors.txt for code contributors and overview of BadgerDB.
 *
 * @section LICENSE
 * Copyright (c) 2012 Database Group, Computer Sciences Department, University of Wisconsin-Madison.
 */

//Name: Qian Zhang
//Campus ID: 9078035962
//Email: qzhang348@wisc.edu

#include "btree.h"
#include "filescan.h"
#include "exceptions/bad_index_info_exception.h"
#include "exceptions/bad_opcodes_exception.h"
#include "exceptions/bad_scanrange_exception.h"
#include "exceptions/no_such_key_found_exception.h"
#include "exceptions/scan_not_initialized_exception.h"
#include "exceptions/index_scan_completed_exception.h"
#include "exceptions/file_not_found_exception.h"
#include "exceptions/end_of_file_exception.h"


//#define DEBUG

namespace badgerdb
{

// -----------------------------------------------------------------------------
// BTreeIndex::BTreeIndex -- Constructor
// -----------------------------------------------------------------------------

BTreeIndex::BTreeIndex(const std::string & relationName,
		std::string & outIndexName,
		BufMgr *bufMgrIn,
		const int attrByteOffset,
		const Datatype attrType)
{
	//assign value to data members
	bufMgr = bufMgrIn;
	headerPageNum = 1;
	attributeType = attrType;
	this->attrByteOffset = attrByteOffset;
	scanExecuting = false;

	//produce index file name
	std::ostringstream idxStr;
	idxStr << relationName << '.' << attrByteOffset;
	outIndexName = idxStr.str();

	try
	{
		//try to open the index file if it already exists
		file = new BlobFile(outIndexName, false);
		//read the head page of this index file
		bufMgr->readPage(file, headerPageNum, currentPageData);
		IndexMetaInfo* meta_info = (IndexMetaInfo*)currentPageData;
		//see if the infor in head page match the index infor
		if ((strcmp(meta_info->relationName, relationName.c_str()))!= 0 || meta_info->attrByteOffset != attrByteOffset || meta_info->attrType != attributeType)
			throw BadIndexInfoException("Index file doesn't match");
		//read the root page num
		rootPageNum = meta_info->rootPageNo;
		bufMgr->unPinPage(file, headerPageNum, false);
	}
	catch (FileNotFoundException e) 
	{
		//create index file
		file = new BlobFile(outIndexName, true);
		//allocate head page
		bufMgr->allocPage(file, headerPageNum, currentPageData);
		bzero((void*)currentPageData, Page::SIZE);
		IndexMetaInfo* meta_info = (IndexMetaInfo*)currentPageData;
		//insert infor into head page
		strcpy(meta_info->relationName, relationName.c_str());
		meta_info->attrByteOffset = attrByteOffset;
		meta_info->attrType = attrType;
		meta_info->rootPageNo = 2;
		//flush head page into index file
		bufMgr->unPinPage(file, headerPageNum, true);
		//allocate root page
		bufMgr->allocPage(file, rootPageNum, currentPageData);
		bzero((void*)currentPageData, Page::SIZE);
		NonLeafNodeInt* nonLeafNode_info = (NonLeafNodeInt *)currentPageData;
		nonLeafNode_info->level = 1;
		//set initial key value of the root node
		int ini_key = 2147483647;
		nonLeafNode_info->keyArray[0] = ini_key;
		//keep root page pointer
		//Page* rootPage = currentPageData;
		//allocate first leaf node
		bufMgr->allocPage(file, currentPageNum, currentPageData);
		bzero((void*)currentPageData, Page::SIZE);
		//std::cout << currentPageNum << std::endl;
		//set initial page id of root page
		nonLeafNode_info->pageNoArray[0] = currentPageNum;
		//unpin root page and leaf page
		bufMgr->unPinPage(file, rootPageNum, true);
		bufMgr->unPinPage(file, currentPageNum, false);

		/*
		bufMgr->readPage(file, rootPageNum, currentPageData);
		NonLeafNodeInt* test = (NonLeafNodeInt*)currentPageData;
		std::cout << test->pageNoArray[0] << std::endl;
		std::cout << rootPageNum << std::endl;
		bufMgr->unPinPage(file, rootPageNum, false);
		*/

		//scan relation file, insert entry to index file
		FileScan fscan(relationName, bufMgr);
		try
		{
			RecordId scanRid;
			while (1)
			{
				fscan.scanNext(scanRid);
				
				//std::cout << scanRid.page_number << std::endl;
				//std::cout << scanRid.slot_number << std::endl;
				//std::cout << "test" << std::endl;
				/*
				bufMgr->readPage(file, rootPageNum, currentPageData);
				NonLeafNodeInt* test = (NonLeafNodeInt*)currentPageData;
				for (int k = 0; k < INTARRAYNONLEAFSIZE; k++)
				{
					if(test->keyArray[k]!=0)
						std::cout << test->keyArray[k] << std::endl;
					if (test->pageNoArray[k] != 0)
						std::cout << test->pageNoArray[k] << std::endl;
				}
				bufMgr->unPinPage(file, rootPageNum, false);
				*/

				std::string recordStr = fscan.getRecord();
				const char* record = recordStr.c_str();
				insertEntry((void *)(record + attrByteOffset), scanRid);
			}
		}
		catch (EndOfFileException e)
		{
		}
	}
}


// -----------------------------------------------------------------------------
// BTreeIndex::~BTreeIndex -- destructor
// -----------------------------------------------------------------------------

BTreeIndex::~BTreeIndex()
{
	scanExecuting = false;
	bufMgr->flushFile(file);
	delete file;
}

// -----------------------------------------------------------------------------
// BTreeIndex::insertEntry
// -----------------------------------------------------------------------------

const void BTreeIndex::insertEntry(const void *key, const RecordId rid) 
{
	//read root node page
	bufMgr->readPage(file, rootPageNum, currentPageData);
	currentPageNum = rootPageNum;
	//track route in the tree when insert
	std::vector<PageId> pageIdTrack;
	pageIdTrack.push_back(currentPageNum);
	//find non leaf node with level 1
	PageId key_pid;
	while (1)
	{
		if (((NonLeafNodeInt*)currentPageData)->level != 1)
		{
			//find page id based on the key
			findKeyPidInNonLeafNode(currentPageData, key, key_pid);
			//unpin the old page
			bufMgr->unPinPage(file, currentPageNum, false);
			//read the new page
			bufMgr->readPage(file, key_pid, currentPageData);
			currentPageNum = key_pid;
			//track node
			pageIdTrack.push_back(currentPageNum);
		}
		else
		{
			/*
			NonLeafNodeInt* test = (NonLeafNodeInt*)currentPageData;
			for (int k = 0; k < INTARRAYNONLEAFSIZE; k++)
			{
				if (test->keyArray[k] != 0)
					std::cout << test->keyArray[k] << std::endl;
				if (test->pageNoArray[k] != 0)
					std::cout << test->pageNoArray[k] << std::endl;
			}
			*/

			//find page id based on the key
			findKeyPidInNonLeafNode(currentPageData, key, key_pid);
			//unpin the old page
			bufMgr->unPinPage(file, currentPageNum, false);
			//read the new page which is now a leaf page
			bufMgr->readPage(file, key_pid, currentPageData);
			currentPageNum = key_pid;
			//track node
			pageIdTrack.push_back(currentPageNum);
			//std::cout << currentPageNum << std::endl;
			/*debug
			for (int i = 0; i < pageIdTrack.size(); i++)
			{
				std::cout << pageIdTrack[i] << std::endl;
			}
			*/
			//if the leaf page is not full, insert key and rid
			if (!isLeafNodeFull(currentPageData))
			{
				insertKeyRidToLeaf(currentPageData, key, rid);
				bufMgr->unPinPage(file, currentPageNum, true);
				/*
				bufMgr->readPage(file, rootPageNum, currentPageData);
				NonLeafNodeInt* test = (NonLeafNodeInt*)currentPageData;
				std::cout << test->pageNoArray[0] << std::endl;
				std::cout << rootPageNum << std::endl;
				bufMgr->unPinPage(file, rootPageNum, false);
				*/
				return;
			}
			//if full, split ups
			else
			{
				int pushKey;
				splitLeafNode(currentPageData,key,rid,(void*)&pushKey);
				/*
				NonLeafNodeInt* test = (NonLeafNodeInt*)currentPageData;
				for (int k = 0; k < INTARRAYLEAFSIZE; k++)
				{
					if (test->keyArray[k] != 0)
						std::cout << test->keyArray[k] << std::endl;
				}
				*/
				//std::cout << currentPageNum << std::endl;
				bufMgr->unPinPage(file, currentPageNum, true);
				//std::cout << currentPageNum << std::endl;
				//std::cout << pushKey << std::endl;
				//bufMgr->readPage(file, rootPageNum, currentPageData);
				//NonLeafNodeInt* test = (NonLeafNodeInt*)currentPageData;
				//std::cout << test->pageNoArray[0] << std::endl;
				//std::cout << rootPageNum << std::endl;
				//bufMgr->unPinPage(file, rootPageNum, false);
				//copy up key into non leaf node
				copyUpKeyIntoNonleaf(pageIdTrack, (void*)&pushKey);
				return;
			}
		}
	}
}

// -----------------------------------------------------------------------------
// BTreeIndex::startScan
// -----------------------------------------------------------------------------

const void BTreeIndex::startScan(const void* lowValParm,
				   const Operator lowOpParm,
				   const void* highValParm,
				   const Operator highOpParm)
{
	if (*(int*)lowValParm > *(int*)highValParm)
		throw BadScanrangeException();
	if ((lowOpParm != GT&&lowOpParm != GTE) || (highOpParm != LT&&highOpParm != LTE))
		throw BadOpcodesException();

	lowOp = lowOpParm;
	highOp = highOpParm;
	lowValInt = *(int*)lowValParm;
	highValInt = *(int*)highValParm;
	scanExecuting = true;
	nextEntry = -1;

	currentPageNum = rootPageNum;
	bool found = findKeyByScanBTree(false);//not leaf
	if (!found)
	{
		scanExecuting = false;
		throw NoSuchKeyFoundException();
	}
}

// -----------------------------------------------------------------------------
// BTreeIndex::scanNext
// -----------------------------------------------------------------------------

const void BTreeIndex::scanNext(RecordId& outRid)
{
	if (scanExecuting == false)
		throw ScanNotInitializedException();
	if (nextEntry == -1)
		throw IndexScanCompletedException();
	LeafNodeInt* leafNode = (LeafNodeInt*)currentPageData;
	outRid = leafNode->ridArray[nextEntry];

	//update nextEntry
	PageId newLeafPid;
	bool isValidIndex = false;
	bool lowBoundPass;
	bool highBoundPass;
	if (nextEntry + 1 == INTARRAYLEAFSIZE)
		isValidIndex = false;
	else
	{
		for (int i = nextEntry + 1; i < INTARRAYLEAFSIZE; i++)
		{
			if (leafNode->ridArray[i].slot_number == 0 || leafNode->ridArray[i].page_number == 0)
			{
				isValidIndex = false;
				break;
			}
			else
			{
				lowBoundPass = ((leafNode->keyArray[i] > lowValInt) && (lowOp == GT)) || ((leafNode->keyArray[i] >= lowValInt) && (lowOp == GTE));
				highBoundPass = ((leafNode->keyArray[i] < highValInt) && (highOp == LT)) || ((leafNode->keyArray[i] <= highValInt) && (highOp == LTE));
				if (lowBoundPass&&highBoundPass)
				{
					nextEntry = i;
					isValidIndex = true;
					break;
				}
			}
		}
	}

	if (isValidIndex == false)
	{
		nextEntry = -1;
		newLeafPid = leafNode->rightSibPageNo;
		bufMgr->unPinPage(file, currentPageNum, false);
		if (newLeafPid == 0)
			nextEntry = -1;
		else
		{
			currentPageNum = newLeafPid;
			bufMgr->readPage(file, currentPageNum, currentPageData);
			leafNode = (LeafNodeInt*)currentPageData;
			for (int i = 0; i < INTARRAYLEAFSIZE; i++)
			{
				if (leafNode->ridArray[i].slot_number == 0 || leafNode->ridArray[i].page_number == 0)
				{
					break;
				}
				lowBoundPass = ((leafNode->keyArray[i] > lowValInt) && (lowOp == GT)) || ((leafNode->keyArray[i] >= lowValInt) && (lowOp == GTE));
				highBoundPass = ((leafNode->keyArray[i] < highValInt) && (highOp == LT)) || ((leafNode->keyArray[i] <= highValInt) && (highOp == LTE));
				if (lowBoundPass&&highBoundPass)
				{
					nextEntry = i;
					break;
				}
			}
			if (nextEntry == -1)
				bufMgr->unPinPage(file, currentPageNum, false);
		}
	}
}

// -----------------------------------------------------------------------------
// BTreeIndex::endScan
// -----------------------------------------------------------------------------
//
const void BTreeIndex::endScan() 
{
	if (!scanExecuting)
		throw ScanNotInitializedException();
	scanExecuting = false;
}

//Insert key into non leaf node
void BTreeIndex::insertKeyIntoNonLeafNode(Page* page, int insertIndex, void* key)
{
	NonLeafNodeInt* nonLeafNodeInfo = (NonLeafNodeInt *)page;
	std::vector<int> veckey;
	bool insertComplete = false;
	for (int i = 0; i < INTARRAYNONLEAFSIZE;)
	{
		if (nonLeafNodeInfo->pageNoArray[i+1]==0)
			break;
		if (!insertComplete&&i == insertIndex)
		{
			veckey.push_back(*(int*)key);
			insertComplete = true;
		}
		else
		{
			veckey.push_back(nonLeafNodeInfo->keyArray[i]);
			i++;
		}
	}
	if (!insertComplete)
	{
		veckey.push_back(*(int*)key);
	}
	int vecIndex;
	for (vecIndex = insertIndex; vecIndex < veckey.size(); vecIndex++)
	{
		//std::cout << nonLeafNodeInfo->keyArray[vecIndex] << std::endl;
		nonLeafNodeInfo->keyArray[vecIndex] = veckey[vecIndex];
	}
}

//Insert page id into non leaf node
void BTreeIndex::insertPidIntoNonLeafNode(Page* page, int insertIndex, PageId pid)
{
	NonLeafNodeInt* nonLeafNodeInfo = (NonLeafNodeInt *)page;
	std::vector<int> vecPid;
	bool insertComplete = false;
	if (nonLeafNodeInfo->pageNoArray[0])
		vecPid.push_back(nonLeafNodeInfo->pageNoArray[0]);
	//std::cout << nonLeafNodeInfo->pageNoArray[0] << std::endl;
	//std::cout << currentPageNum << std::endl;
	for (int i = 0; i < INTARRAYNONLEAFSIZE;)
	{
		if (nonLeafNodeInfo->pageNoArray[i+1]==0)
			break;
		if (!insertComplete && i == insertIndex)
		{
			vecPid.push_back(pid);
			insertComplete = true;
		}
		else
		{
			vecPid.push_back(nonLeafNodeInfo->pageNoArray[i+1]);
			i++;
		}
	}
	if (!insertComplete)
	{
		vecPid.push_back(pid);
	}
	int vecIndex;
	for (vecIndex = insertIndex+1; vecIndex < vecPid.size(); vecIndex++)
	{
		nonLeafNodeInfo->pageNoArray[vecIndex] = vecPid[vecIndex];
	}
}

//find pid in non leaf node based on key value 
void BTreeIndex::findKeyPidInNonLeafNode(Page* page, const void* key, PageId& pid)
{
	int i;
	//std::cout << *(int*)key << std::endl;
	NonLeafNodeInt* nonLeafNode = (NonLeafNodeInt*)page;
	for (i = 0; i < INTARRAYNONLEAFSIZE; i++)
	{
		if (nonLeafNode->pageNoArray[i + 1] == 0)
		{
			pid = nonLeafNode->pageNoArray[i];
			break;
		}
		if (*(int*)key < nonLeafNode->keyArray[i])
		{
			pid = nonLeafNode->pageNoArray[i];
			break;
		}
	}
}

//check if the leaf node page is full
bool BTreeIndex::isLeafNodeFull(Page* page)
{
	int count = 0;
	int i;
	LeafNodeInt* leafNode = (LeafNodeInt*)page;
	for (i = 0; i < INTARRAYLEAFSIZE; i++)
	{
		if (leafNode->ridArray[i].page_number > 0 && leafNode->ridArray[i].slot_number > 0)
			//record is valid
			count++;
	}
	return count == INTARRAYLEAFSIZE;
}

//inset key and rid into leaf node page
void BTreeIndex::insertKeyRidToLeaf(Page* page, const void* key, RecordId rid)
{
	//find insert index
	int i;
	int insert_index;
	LeafNodeInt* leafNode = (LeafNodeInt*)page;
	for (i = 0; i < INTARRAYLEAFSIZE; i++)
	{
		if (leafNode->ridArray[i].slot_number == 0 || leafNode->ridArray[i].page_number == 0)
		{
			insert_index = i;
			break;
		}
		else
		{
			if (*(int*)key < leafNode->keyArray[i])
			{
				insert_index = i;
				break;
			}
		}
	}
	//inset key and rid in insert_index
	std::vector<int> veckey;
	std::vector<RecordId> vecRid;
	bool insertComplete = false;
	for (i = 0; i < INTARRAYLEAFSIZE;)
	{
		if (leafNode->ridArray[i].slot_number == 0 || leafNode->ridArray[i].page_number == 0)
			break;
		if (!insertComplete&&i == insert_index)
		{
			veckey.push_back(*(int*)key);
			vecRid.push_back(rid);
			insertComplete = true;
		}
		else
		{
			veckey.push_back(leafNode->keyArray[i]);
			vecRid.push_back(leafNode->ridArray[i]);
			i++;
		}
	}
	if (!insertComplete)
	{
		veckey.push_back(*(int*)key);
		vecRid.push_back(rid);
		insertComplete = true;
	}
	int vecIndex;
	for (vecIndex = insert_index; vecIndex < veckey.size(); vecIndex++)
	{
		leafNode->keyArray[vecIndex] = veckey[vecIndex];
		leafNode->ridArray[vecIndex] = vecRid[vecIndex];
	}
}

//split leaf node
void BTreeIndex::splitLeafNode(Page* page, const void* key, RecordId rid, void* pushKey)
{
	//find insert index
	int i;
	int insert_index;
	LeafNodeInt* leafNode = (LeafNodeInt*)page;
	for (i = 0; i < INTARRAYLEAFSIZE; i++)
	{
		if (*(int*)key < leafNode->keyArray[i])
		{
			insert_index = i;
			break;
		}
	}
	insert_index = i;
	//save value in vectors
	std::vector<int> veckey;
	std::vector<RecordId> vecRid;
	bool insertComplete = false;
	for (i = 0; i < INTARRAYLEAFSIZE;)
	{
		if (!insertComplete&&i == insert_index)
		{
			veckey.push_back(*(int*)key);
			vecRid.push_back(rid);
			insertComplete = true;
		}
		else
		{
			veckey.push_back(leafNode->keyArray[i]);
			vecRid.push_back(leafNode->ridArray[i]);
			i++;
		}
	}
	if (!insertComplete)
	{
		veckey.push_back(*(int*)key);
		vecRid.push_back(rid);
		insertComplete = true;
	}
	//split up
	Page* newPage;
	PageId newPageId;
	/*debug*/
	//std::cout << "test" << std::endl;
	//std::cout << currentPageNum << std::endl;
	bufMgr->allocPage(file, newPageId, newPage);
	/*debug*/
	//std::cout << newPageId << std::endl;
	bzero((void*)newPage, Page::SIZE);
	LeafNodeInt* newLeafNode = (LeafNodeInt*)newPage;
	int vecIndex;
	for (vecIndex = 0; vecIndex < INTARRAYLEAFSIZE/2; vecIndex++)
	{
		leafNode->keyArray[vecIndex] = veckey[vecIndex];
		leafNode->ridArray[vecIndex] = vecRid[vecIndex];
	}
	for (; vecIndex < INTARRAYLEAFSIZE+1; vecIndex++)
	{
		newLeafNode->keyArray[vecIndex - INTARRAYLEAFSIZE / 2] = veckey[vecIndex];
		newLeafNode->ridArray[vecIndex - INTARRAYLEAFSIZE / 2] = vecRid[vecIndex];
	}
	bzero((void*)&(leafNode->keyArray[INTARRAYLEAFSIZE / 2]), sizeof(int)*(INTARRAYLEAFSIZE / 2));
	bzero((void*)&(leafNode->ridArray[INTARRAYLEAFSIZE / 2]), sizeof(RecordId)*(INTARRAYLEAFSIZE / 2));
	*(int*)pushKey = newLeafNode->keyArray[0];
	PageId original_rightPid = leafNode->rightSibPageNo;
	leafNode->rightSibPageNo = newPageId;
	newLeafNode->rightSibPageNo = original_rightPid;
	bufMgr->unPinPage(file,newPageId,true);
}

//copy key from leaf node to non leaf node
void BTreeIndex::copyUpKeyIntoNonleaf(std::vector<PageId> pidTrack, void* pushKey)
{
	currentPageNum = pidTrack[pidTrack.size() - 2];
	//std::cout << currentPageNum << std::endl;
	bufMgr->readPage(file, currentPageNum, currentPageData);
	//std::cout << currentPageNum << std::endl;
	//std::cout << ((NonLeafNodeInt*)currentPageData)->pageNoArray[0] << std::endl;
	if (!isNonLeafNodeFull(currentPageData))
	{
		//std::cout << "test" << std::endl;
		int copyIndex;
		findKeyIndexInNonLeafNode(currentPageData, pushKey, copyIndex);
		//std::cout << currentPageNum << std::endl;
		//std::cout << ((NonLeafNodeInt*)currentPageData)->pageNoArray[0] << std::endl;
		insertKeyIntoNonLeafNode(currentPageData, copyIndex, pushKey);
		//std::cout << currentPageNum << std::endl;
		//std::cout << ((NonLeafNodeInt*)currentPageData)->pageNoArray[0] << std::endl;
		//std::cout << copyIndex << std::endl;
		//std::cout << "test" << std::endl;
		Page* leafPage;
		bufMgr->readPage(file, pidTrack[pidTrack.size() - 1], leafPage);
		/*
		for (int k = 0; k < INTARRAYNONLEAFSIZE; k++)
		{
			NonLeafNodeInt* nonLeafNodeInfo = (NonLeafNodeInt*)currentPageData;
			if (nonLeafNodeInfo->pageNoArray[k] != 0)
				std::cout << nonLeafNodeInfo->pageNoArray[k] << std::endl;
		}
		*/
		//std::cout << currentPageNum << std::endl;
		//std::cout << ((NonLeafNodeInt*)currentPageData)->pageNoArray[0] << std::endl;
		//std::cout << ((LeafNodeInt*)leafPage)->rightSibPageNo << std::endl;
		insertPidIntoNonLeafNode(currentPageData, copyIndex, ((LeafNodeInt*)leafPage)->rightSibPageNo);
		//std::cout << "test" << std::endl;
		bufMgr->unPinPage(file, currentPageNum, true);
		bufMgr->unPinPage(file, pidTrack[pidTrack.size() - 1], false);
	}
	else//split up non leaf node// recursive call
	{
		Page* leafPage;
		bufMgr->readPage(file, pidTrack[pidTrack.size() - 1], leafPage);
		PageId newLeafPageId = ((LeafNodeInt*)leafPage)->rightSibPageNo;
		bufMgr->unPinPage(file, pidTrack[pidTrack.size() - 1], false);
		std::vector<PageId> newPidTrack(pidTrack);
		newPidTrack.pop_back();
		PageId oldPageId = currentPageNum;
		splitNonleafNode(currentPageData, pushKey, oldPageId, newLeafPageId, newPidTrack);
	}
}

//check if the non leaf node page is full
bool BTreeIndex::isNonLeafNodeFull(Page* page)
{
	int count = 0;
	int i;
	NonLeafNodeInt* nonLeafNode = (NonLeafNodeInt*)page;
	for (i = 0; i <= INTARRAYNONLEAFSIZE; i++)
	{
		if (nonLeafNode->pageNoArray[i]> 0)
			//page id is valid
			count++;
	}
	return count == INTARRAYNONLEAFSIZE +1;
}

//find copy index in non leaf node based on key value 
void BTreeIndex::findKeyIndexInNonLeafNode(Page* page, void* key, int& copyIndex)
{
	int i;
	NonLeafNodeInt* nonLeafNode = (NonLeafNodeInt*)page;
	for (i = 0; i < INTARRAYNONLEAFSIZE; i++)
	{
		if (nonLeafNode->pageNoArray[i+1] == 0)
		{
			copyIndex = i;
			break;
		}
		else if (*(int*)key < nonLeafNode->keyArray[i])
		{
			//std::cout << nonLeafNode->keyArray[i] << std::endl;
			copyIndex = i;
			break;
		}
	}
}

//split non leaf node
void BTreeIndex::splitNonleafNode(Page* page, void* key, PageId oldPid, PageId pid, std::vector<PageId> pidTrack)
{
	Page* newNonNodePage;
	PageId newNonNodePid;
	bufMgr->allocPage(file, newNonNodePid, newNonNodePage);
	bzero((void*)newNonNodePage, Page::SIZE);
	NonLeafNodeInt* newNonLeafNode = (NonLeafNodeInt*)newNonNodePage;
	//find insert index
	int i;
	int insert_index;
	NonLeafNodeInt* nonLeafNode = (NonLeafNodeInt*)page;
	for (i = 0; i < INTARRAYNONLEAFSIZE; i++)
	{
		if (*(int*)key < nonLeafNode->keyArray[i])
		{
			insert_index = i;
			break;
		}
	}
	insert_index = i;
	//save value in vectors
	std::vector<int> veckey;
	std::vector<PageId> vecPid;
	bool insertComplete = false;
	vecPid.push_back(nonLeafNode->pageNoArray[0]);
	for (i = 0; i < INTARRAYNONLEAFSIZE;)
	{
		if (!insertComplete&&i == insert_index)
		{
			veckey.push_back(*(int*)key);
			vecPid.push_back(pid);
			insertComplete = true;
		}
		else
		{
			veckey.push_back(nonLeafNode->keyArray[i]);
			vecPid.push_back(nonLeafNode->pageNoArray[i+1]);
			i++;
		}
	}
	if (!insertComplete)
	{
		veckey.push_back(*(int*)key);
		vecPid.push_back(pid);
		insertComplete = true;
	}
	//split up
	int vecIndex;
	nonLeafNode->pageNoArray[0] = vecPid[0];
	for (vecIndex = 0; vecIndex < INTARRAYNONLEAFSIZE / 2; vecIndex++)
	{
		nonLeafNode->keyArray[vecIndex] = veckey[vecIndex];
		nonLeafNode->pageNoArray[vecIndex+1] = vecPid[vecIndex+1];
	}
	int pushKey = veckey[vecIndex];
	vecIndex++;
	newNonLeafNode->pageNoArray[0] = vecPid[vecIndex];
	for (; vecIndex < INTARRAYNONLEAFSIZE + 1; vecIndex++)
	{
		newNonLeafNode->keyArray[vecIndex - INTARRAYNONLEAFSIZE / 2 - 1] = veckey[vecIndex];
		newNonLeafNode->pageNoArray[vecIndex - INTARRAYNONLEAFSIZE / 2] = vecPid[vecIndex];
	}
	newNonLeafNode->level = nonLeafNode->level;
	bzero((void*)&(newNonLeafNode->keyArray[INTARRAYNONLEAFSIZE / 2]), sizeof(int)*(INTARRAYNONLEAFSIZE / 2 + 1));
	bzero((void*)&(newNonLeafNode->pageNoArray[INTARRAYNONLEAFSIZE / 2+1]), sizeof(PageId)*(INTARRAYNONLEAFSIZE / 2 + 1));
	bufMgr->unPinPage(file, newNonNodePid, true);
	bufMgr->unPinPage(file, oldPid, true);
	//moving up
	//if this non leaf page is root page, height + 1
	if (oldPid == rootPageNum)
	{
		bufMgr->allocPage(file, currentPageNum, currentPageData);
		bzero((void*)currentPageData, Page::SIZE);
		rootPageNum = currentPageNum;
		((NonLeafNodeInt*)currentPageData)->keyArray[0] = pushKey;
		((NonLeafNodeInt*)currentPageData)->pageNoArray[0] = oldPid;
		((NonLeafNodeInt*)currentPageData)->pageNoArray[1] = newNonNodePid;
		((NonLeafNodeInt*)currentPageData)->level = 0;
		bufMgr->unPinPage(file, currentPageNum, true);
		//update information of the index file
		bufMgr->readPage(file, headerPageNum, currentPageData);
		IndexMetaInfo* headInfor = (IndexMetaInfo*)currentPageData;
		headInfor->rootPageNo = rootPageNum;
		bufMgr->unPinPage(file, headerPageNum, true);
		return;
	}
	else
	{
		currentPageNum = pidTrack[pidTrack.size() - 2];
		bufMgr->readPage(file, currentPageNum, currentPageData);
		if (!isNonLeafNodeFull(currentPageData))
		{
			int copyIndex;
			findKeyIndexInNonLeafNode(currentPageData, (void*)&pushKey, copyIndex);
			insertKeyIntoNonLeafNode(currentPageData, copyIndex, (void*)&pushKey);
			insertPidIntoNonLeafNode(currentPageData, copyIndex, newNonNodePid);
			bufMgr->unPinPage(file, currentPageNum, true);
			return;
		}
		else 
		{
			std::vector<PageId> newPidTrack(pidTrack);
			newPidTrack.pop_back();
			PageId oldPageId = currentPageNum;
			//recursively call
			splitNonleafNode(currentPageData, (void*)&pushKey, oldPageId, newNonNodePid, newPidTrack);
		}
	}
}

//scan the tree to find the first entry in leaf node
bool BTreeIndex::findKeyByScanBTree(bool isLeaf)
{
	bool keyFound = false;
	std::vector<PageId> candidate_pid;
	std::vector<PageId>::iterator pidVecIter;
	bufMgr->readPage(file, currentPageNum, currentPageData);
	if (isLeaf)
	{
		bool lowBoundPass;
		bool highBoundPass;
		LeafNodeInt* leafNode = (LeafNodeInt*)currentPageData;
		for (int i = 0; i < INTARRAYLEAFSIZE; i++)
		{
			if (leafNode->ridArray[i].page_number == 0 || leafNode->ridArray[i].slot_number == 0)
			{
				bufMgr->unPinPage(file, currentPageNum, false);
				return false;
			}
			lowBoundPass = ((leafNode->keyArray[i] > lowValInt) && (lowOp == GT)) || ((leafNode->keyArray[i] >= lowValInt) && (lowOp == GTE));
			highBoundPass = ((leafNode->keyArray[i] < highValInt) && (highOp == LT)) || ((leafNode->keyArray[i] <= highValInt) && (highOp == LTE));
			if (lowBoundPass&&highBoundPass)
			{
				nextEntry = i;
				return true;
			}
		}
	}
	else//non leaf node
	{
		bool isLeafTemp = false;
		//left most candidate node
		int firstFoundIndex = -1;
		NonLeafNodeInt* nonLeafNode = (NonLeafNodeInt*)currentPageData;
		int i;
		for (i = 0; i < INTARRAYNONLEAFSIZE; i++)
		{
			if (nonLeafNode->pageNoArray[i + 1] == 0)
				break;
			if (nonLeafNode->keyArray[i] > lowValInt)
			{
				firstFoundIndex = i;
				break;
			}
		}
		if (firstFoundIndex == -1 && nonLeafNode->pageNoArray[i] > 0)
			firstFoundIndex = i;
		if (firstFoundIndex == -1)
		{
			bufMgr->unPinPage(file, currentPageNum, false);
			return false;
		}
		keyFound = true;
		for (i = firstFoundIndex; i < INTARRAYNONLEAFSIZE; i++)
		{
			if (nonLeafNode->pageNoArray[i] > 0)
			{
				if (i == 0)
					candidate_pid.push_back(nonLeafNode->pageNoArray[0]);
				else
				{
					if (nonLeafNode->keyArray[i - 1] > highValInt)
						break;
					else
						candidate_pid.push_back(nonLeafNode->pageNoArray[i]);
				}
			}
			else
				break;
		}
		//scan all the candidate pages
		if (nonLeafNode->level == 1)
			isLeafTemp = true;
		bufMgr->unPinPage(file, currentPageNum, false);
		for (pidVecIter = candidate_pid.begin(); pidVecIter < candidate_pid.end(); pidVecIter++)
		{
			currentPageNum = *pidVecIter;
			keyFound = findKeyByScanBTree(isLeafTemp);
			if (keyFound)
				return true;//find first entry in leaf node, now the current page is the leaf page
		}
		return false;
	}
	return false;
}
}
